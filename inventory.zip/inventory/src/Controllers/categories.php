<?php

use Slim\Http\Request; //namespace
use Slim\Http\Response; //namespace

//include categoriesProc.php file
include __DIR__ . '/../function/categoriesProc.php';

//read table products
$app->get('/allcategories', function (Request $request, Response $response, array $arg){
  
  $data = getAllCategories($this->db);
  if (empty($data)) {
    return $this->response->withJson(array('error' => 'no data'),404);
  }
  return $this->response->withJson(array('error' => $data),200);
  });

  
  
  $app->post ( '/categories', function ($request, $response, $args) {

  
    $form_data = $request->getParsedBody();
    //return $this->response->withJson($form_data, 200);
 
    $data = createCategories($this->db, $form_data);
       if ($data <= 0) {
          return $this->response->withJson(array('error' => 'fail'), 500);
       }
     return $this->response->withJson(array('data' => 'success'), 200);
 
    });

    //request table products by condition
$app->get('/categories/[{id}]', function ($request, $response, $args){
    
  $categoriesId = $args['id'];
 if (!is_numeric($categoriesId)) {
    return $this->response->withJson(array('error' => 'numeric paremeter required'), 422);
 }
$data = getCategories($this->db,$categoriesId);
if (empty($data)) {
  return $this->response->withJson(array('error' => 'no data'), 404);
}
 return $this->response->withJson(array('data' => $data), 200);
});

//delete row
$app->delete('/categories/del/[{id}]', function ($request, $response, $args){
  
$categoriesId = $args['id'];
if (!is_numeric($categoriesId)) {
  return $this->response->withJson(array('error' => 'numeric paremeter required'), 422);
}
$data = deletecategories($this->db,$categoriesId);
if (empty($data)) {
return $this->response->withJson(array($categoriesId=> 'is successfully deleted'), 202);};
});


//put table categories
$app->put('/categories/put/[{id}]', function ($request,  $response,  $args){
 $categoriesId = $args['id'];
 $date = date("Y-m-j h:i:s");
 
if (!is_numeric($categoriesId)) {
   return $this->response->withJson(array('error' => 'numeric paremeter required'), 422);
}
 $form_dat=$request->getParsedBody();
 
$data=updateCategories($this->db,$form_dat,$categoriesId,$date);

if ($data <=0)
return $this->response->withJson(array('data' => 'successfully updated'), 200);
});

