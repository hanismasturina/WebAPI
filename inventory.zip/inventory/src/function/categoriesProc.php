<?php

//get all categories
function getAllCategories($db)
{
$sql = 'Select id, name, description, created, modified from categories ';
$stmt = $db->prepare ($sql);
$stmt ->execute();
return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
//get categories by id
function getCategories($db, $categoriesId)
{
$sql = 'Select id, name, description, created, modified from categories  ';
$sql .= 'Where p.id = :id'; 
$stmt = $db->prepare ($sql);
$id = (int) $categoriesId;
$stmt->bindParam(':id', $id, PDO::PARAM_INT);
$stmt->execute();
return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

//insert new categories
function createCategories($db, $form_data)
{
$sql = 'Insert into categories (name, description, categories_id, created, modified) ';
$sql .= 'values (:name, :description, :categories_id, :created, :modified)';
$stmt = $db->prepare ($sql);
$stmt->bindParam(':name', $form_data['name']);
$stmt->bindParam(':description', $form_data['description']);
$stmt->bindParam(':categories_id', intval($form_data['categories_id']));
$stmt->bindParam(':created', $form_data['created']);
$stmt->bindParam(':modified', $form_data['modified']);
$stmt->execute();
return $db->lastInsertID();//insert last number.. continue
}

//delete category by id
function deleteCategories($db,$categoriesId) {
    $sql = ' Delete from categories where id = :id';
    $stmt = $db->prepare($sql);
    $id = (int)$categoriesId;
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    }
    
    //update product by id
function updateCategories($db,$form_dat,$categoriesId,$date) {
    $sql = 'UPDATE categories SET name = :name , description = :description  ,  created = :created, modified = :modified ';
    $sql .=' WHERE id = :id';

    $stmt = $db->prepare ($sql);
    $id = (int)$categoriesId;
    $mod = $date;

    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->bindParam(':name', $form_dat['name']);
    $stmt->bindParam(':description', $form_dat['description']);
    $stmt->bindParam(':created', $form_dat['created']);
    $stmt->bindParam(':modified', $form_dat['modified']);
    $stmt->execute();
  
}

