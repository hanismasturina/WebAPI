<?php

//hello route
require __DIR__ . '/Controllers/hello.php';

//products route
require __DIR__ . '/Controllers/product.php';

//producta route
require __DIR__ . '/Controllers/categories.php';